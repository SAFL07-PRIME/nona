'use client';

import { useEffect, useState, useRef } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { toast } from 'sonner';
import {
  Settings, Users, Key, Bot, ArrowLeft, Loader2, Plus, Trash2, Shield,
  Save, Eye, EyeOff, UserCog, Activity, Server, CheckCircle2, XCircle, Wifi
} from 'lucide-react';

export default function AdminPanel() {
  const { user, setViewMode } = useStore();
  const [activeTab, setActiveTab] = useState('settings');

  // Settings state
  const [groqApiKey, setGroqApiKey] = useState('');
  const [aiModel, setAiModel] = useState('llama-3.3-70b-versatile');
  const [systemPrompt, setSystemPrompt] = useState('');
  const [showApiKey, setShowApiKey] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [testingKey, setTestingKey] = useState(false);
  const [keyStatus, setKeyStatus] = useState<'idle' | 'valid' | 'invalid' | 'empty'>('idle');

  // Users state
  const [users, setUsers] = useState<any[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [newUser, setNewUser] = useState({ email: '', password: '', name: '', role: 'USER' });
  const autoSaveTimer = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    loadSettings();
    loadUsers();
  }, []);

  // Auto-save API key when user finishes typing
  const handleApiKeyChange = (value: string) => {
    setGroqApiKey(value);
    setKeyStatus('idle');
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    if (value.length > 5) {
      autoSaveTimer.current = setTimeout(async () => {
        try {
          const res = await fetch('/api/admin/settings', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ groqApiKey: value }),
          });
          if (res.ok) {
            toast.success('API Key tersimpan otomatis!');
            setKeyStatus('valid');
          } else {
            const data = await res.json();
            toast.error(data.error || 'Gagal menyimpan API key');
          }
        } catch {
          toast.error('Gagal menyimpan');
        }
      }, 1500); // Auto-save 1.5 detik setelah berhenti mengetik
    }
  };

  const loadSettings = async () => {
    try {
      const res = await fetch('/api/admin/settings');
      if (res.ok) {
        const data = await res.json();
        setGroqApiKey(data.settings.groqApiKey);
        setAiModel(data.settings.aiModel);
        setSystemPrompt(data.settings.systemPrompt);
        setKeyStatus(data.settings.groqApiKey.length > 0 ? 'valid' : 'empty');
      }
    } catch {
      toast.error('Gagal memuat settings');
    }
  };

  const saveSettings = async () => {
    setSavingSettings(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ groqApiKey, aiModel, systemPrompt }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal menyimpan');
      toast.success('Settings berhasil disimpan!');
      setKeyStatus(groqApiKey.length > 0 ? 'valid' : 'empty');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSavingSettings(false);
    }
  };

  const testApiKey = async () => {
    if (!groqApiKey) {
      setKeyStatus('empty');
      toast.error('Masukkan API key dulu!');
      return;
    }
    setTestingKey(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ groqApiKey, aiModel }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setKeyStatus('valid');
        toast.success(data.message);
      } else {
        setKeyStatus('invalid');
        toast.error('API Key error: ' + (data.error || data.message || 'Unknown error'));
      }
    } catch {
      setKeyStatus('invalid');
      toast.error('Tidak bisa terhubung ke server');
    } finally {
      setTestingKey(false);
    }
  };

  const loadUsers = async () => {
    setLoadingUsers(true);
    try {
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        setUsers(data.users || []);
      }
    } catch {
      toast.error('Gagal memuat users');
    } finally {
      setLoadingUsers(false);
    }
  };

  const addUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newUser),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal menambah user');
      toast.success('User berhasil ditambahkan!');
      setAddUserOpen(false);
      setNewUser({ email: '', password: '', name: '', role: 'USER' });
      loadUsers();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const updateUserRole = async (userId: string, role: string) => {
    try {
      const res = await fetch('/api/admin/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, role }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal mengubah role');
      toast.success('Role berhasil diubah!');
      loadUsers();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const deleteUser = async (userId: string) => {
    if (!confirm('Yakin ingin menghapus user ini?')) return;
    try {
      const res = await fetch(`/api/admin/users?id=${userId}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal menghapus user');
      toast.success('User berhasil dihapus!');
      loadUsers();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const groqModels = [
    { value: 'llama-3.3-70b-versatile', label: 'Llama 3.3 70B Versatile' },
    { value: 'llama-3.1-8b-instant', label: 'Llama 3.1 8B Instant' },
    { value: 'llama3-70b-8192', label: 'Llama 3 70B' },
    { value: 'llama3-8b-8192', label: 'Llama 3 8B' },
    { value: 'mixtral-8x7b-32768', label: 'Mixtral 8x7B' },
    { value: 'gemma2-9b-it', label: 'Gemma 2 9B' },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Header */}
      <header className="border-b bg-muted/30 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => setViewMode('chat')}>
            <ArrowLeft className="h-4 w-4 mr-2" /> Kembali ke Chat
          </Button>
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            <h1 className="font-bold text-lg">Admin Panel</h1>
          </div>
          <Badge variant="secondary" className="ml-auto">
            <Activity className="h-3 w-3 mr-1" /> Online
          </Badge>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 md:p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="h-4 w-4" /> Settings
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2">
              <Users className="h-4 w-4" /> Manajemen User
            </TabsTrigger>
          </TabsList>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="space-y-6">
              {/* API Key Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Key className="h-5 w-5" /> Groq API Key
                  </CardTitle>
                  <CardDescription>
                    Masukkan API key Groq Anda untuk mengaktifkan fitur AI chat. API key akan tersimpan aman di server.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="api-key">API Key</Label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Input
                          id="api-key"
                          type={showApiKey ? 'text' : 'password'}
                          value={groqApiKey}
                          onChange={(e) => handleApiKeyChange(e.target.value)}
                          placeholder="gsk_..."
                          className="pr-10"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8"
                          onClick={() => setShowApiKey(!showApiKey)}
                        >
                          {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      {keyStatus === 'valid' && (
                        <div className="flex items-center gap-1.5 text-green-600 text-sm">
                          <CheckCircle2 className="h-4 w-4" /> API Key valid
                        </div>
                      )}
                      {keyStatus === 'invalid' && (
                        <div className="flex items-center gap-1.5 text-red-500 text-sm">
                          <XCircle className="h-4 w-4" /> API Key tidak valid
                        </div>
                      )}
                      {keyStatus === 'empty' && groqApiKey.length === 0 && (
                        <div className="flex items-center gap-1.5 text-amber-500 text-sm">
                          <XCircle className="h-4 w-4" /> API Key belum diisi
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2 mt-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={testApiKey}
                        disabled={testingKey || !groqApiKey}
                      >
                        {testingKey ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Wifi className="h-4 w-4 mr-1.5" />}
                        Test Koneksi
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Dapatkan API key gratis di{' '}
                      <a href="https://console.groq.com" target="_blank" rel="noopener noreferrer" className="text-primary underline">
                        console.groq.com
                      </a>
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ai-model">Model AI</Label>
                    <Select value={aiModel} onValueChange={setAiModel}>
                      <SelectTrigger id="ai-model">
                        <SelectValue placeholder="Pilih model" />
                      </SelectTrigger>
                      <SelectContent>
                        {groqModels.map((model) => (
                          <SelectItem key={model.value} value={model.value}>
                            {model.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* System Prompt Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bot className="h-5 w-5" /> System Prompt
                  </CardTitle>
                  <CardDescription>
                    Konfigurasi perilaku dan personality AI assistant. Prompt ini akan dikirimkan ke setiap percakapan.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    value={systemPrompt}
                    onChange={(e) => setSystemPrompt(e.target.value)}
                    placeholder="Masukkan system prompt..."
                    rows={5}
                    className="resize-none"
                  />
                </CardContent>
              </Card>

              {/* Server Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Server className="h-5 w-5" /> Informasi Server
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Status</p>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-500" />
                        <p className="text-sm font-medium">Online</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Framework</p>
                      <p className="text-sm font-medium">Next.js 16 + Groq AI</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Database</p>
                      <p className="text-sm font-medium">SQLite (Prisma)</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Admin</p>
                      <p className="text-sm font-medium">{user?.email}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Save Button */}
              <div className="flex justify-end">
                <Button onClick={saveSettings} disabled={savingSettings} size="lg">
                  {savingSettings ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                  Simpan Settings
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" /> Daftar User
                    </CardTitle>
                    <CardDescription className="mt-1">
                      Kelola semua user yang terdaftar. User biasa tidak dapat mengakses panel admin.
                    </CardDescription>
                  </div>
                  <Dialog open={addUserOpen} onOpenChange={setAddUserOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm">
                        <Plus className="h-4 w-4 mr-2" /> Tambah User
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Tambah User Baru</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={addUser} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="add-name">Nama</Label>
                          <Input
                            id="add-name"
                            value={newUser.name}
                            onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                            placeholder="Nama lengkap"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="add-email">Email</Label>
                          <Input
                            id="add-email"
                            type="email"
                            value={newUser.email}
                            onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                            placeholder="email@contoh.com"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="add-password">Password</Label>
                          <Input
                            id="add-password"
                            type="password"
                            value={newUser.password}
                            onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                            placeholder="Minimal 6 karakter"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Role</Label>
                          <Select value={newUser.role} onValueChange={(v) => setNewUser({ ...newUser, role: v })}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="USER">User</SelectItem>
                              <SelectItem value="ADMIN">Admin</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button type="submit" className="w-full">Tambah User</Button>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {loadingUsers ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : users.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">Belum ada user terdaftar</p>
                ) : (
                  <div className="space-y-3">
                    {users.map((u) => (
                      <div
                        key={u.id}
                        className="flex items-center gap-3 p-3 rounded-lg border hover:bg-accent/50 transition-colors"
                      >
                        <Avatar className="h-10 w-10">
                          <AvatarFallback>{u.name.charAt(0).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-sm truncate">{u.name}</p>
                            <Badge variant={u.role === 'ADMIN' ? 'default' : 'secondary'} className="text-xs">
                              {u.role}
                            </Badge>
                            {u.isCurrentUser && (
                              <Badge variant="outline" className="text-xs">Anda</Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                          <p className="text-xs text-muted-foreground">
                            Bergabung: {new Date(u.createdAt).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}
                          </p>
                        </div>
                        {!u.isCurrentUser && (
                          <div className="flex items-center gap-1">
                            <Select
                              value={u.role}
                              onValueChange={(v) => updateUserRole(u.id, v)}
                            >
                              <SelectTrigger className="h-8 w-[100px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="USER">User</SelectItem>
                                <SelectItem value="ADMIN">Admin</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive hover:text-destructive"
                              onClick={() => deleteUser(u.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
