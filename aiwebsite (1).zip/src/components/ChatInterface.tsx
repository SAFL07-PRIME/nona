'use client';

import { useEffect, useRef } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { toast } from 'sonner';
import { Send, Plus, Trash2, MessageSquare, Loader2, Bot, User } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import React from 'react';

export default function ChatInterface() {
  const {
    user, sessions, activeSession, messages, isSending,
    setSessions, setActiveSession, setMessages, addMessage, setSending,
    setSidebarOpen,
  } = useStore();

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [input, setInput] = React.useState('');

  useEffect(() => {
    loadSessions();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadSessions = async () => {
    try {
      const res = await fetch('/api/chat/sessions');
      const data = await res.json();
      if (res.ok) setSessions(data.sessions || []);
    } catch {
      toast.error('Gagal memuat sesi chat');
    }
  };

  const createNewChat = async () => {
    try {
      const res = await fetch('/api/chat/sessions', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        setActiveSession(data.session);
        setMessages([]);
        loadSessions();
        inputRef.current?.focus();
      }
    } catch {
      toast.error('Gagal membuat chat baru');
    }
  };

  const selectSession = async (session: typeof sessions[0]) => {
    setActiveSession(session);
    try {
      const res = await fetch(`/api/chat?sessionId=${session.id}`);
      const data = await res.json();
      if (res.ok) setMessages(data.messages || []);
    } catch {
      toast.error('Gagal memuat pesan');
    }
    // Close sidebar on mobile
    setSidebarOpen(false);
  };

  const deleteSession = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/chat?id=${sessionId}`, { method: 'DELETE' });
      if (res.ok) {
        if (activeSession?.id === sessionId) {
          setActiveSession(null);
          setMessages([]);
        }
        loadSessions();
        toast.success('Chat berhasil dihapus');
      }
    } catch {
      toast.error('Gagal menghapus chat');
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || !activeSession || isSending) return;

    const messageContent = input.trim();
    setInput('');
    addMessage({
      id: 'temp-' + Date.now(),
      role: 'user',
      content: messageContent,
      createdAt: new Date().toISOString(),
    });
    setSending(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: messageContent, sessionId: activeSession.id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal mengirim pesan');

      addMessage({
        id: 'ai-' + Date.now(),
        role: 'assistant',
        content: data.reply,
        createdAt: new Date().toISOString(),
      });
      loadSessions();
    } catch (err: any) {
      toast.error(err.message);
      addMessage({
        id: 'err-' + Date.now(),
        role: 'assistant',
        content: 'Maaf, terjadi kesalahan. Silakan coba lagi.',
        createdAt: new Date().toISOString(),
      });
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="hidden md:flex flex-col w-72 border-r bg-muted/30">
        <div className="p-4 border-b">
          <div className="flex items-center gap-2 mb-3">
            <Bot className="h-6 w-6 text-primary" />
            <h1 className="font-bold text-lg">AdelGPT</h1>
          </div>
          <Button onClick={createNewChat} className="w-full" size="sm">
            <Plus className="h-4 w-4 mr-2" /> Chat Baru
          </Button>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {sessions.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">
                Belum ada chat. Mulai percakapan baru!
              </p>
            )}
            {sessions.map((session) => (
              <div
                key={session.id}
                onClick={() => selectSession(session)}
                className={`group flex items-center gap-2 p-3 rounded-lg cursor-pointer transition-colors hover:bg-accent ${
                  activeSession?.id === session.id ? 'bg-accent text-accent-foreground' : ''
                }`}
              >
                <MessageSquare className="h-4 w-4 shrink-0 opacity-50" />
                <span className="text-sm truncate flex-1">{session.title}</span>
                <button
                  onClick={(e) => deleteSession(session.id, e)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:bg-destructive/10 rounded transition-opacity"
                >
                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                </button>
              </div>
            ))}
          </div>
        </ScrollArea>
        <div className="p-4 border-t">
          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs">
                {user?.name?.charAt(0)?.toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user?.name}</p>
              <p className="text-xs text-muted-foreground truncate">{user?.role}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center gap-3 p-3 border-b bg-muted/30">
          <div className="flex items-center gap-2 flex-1">
            <Bot className="h-5 w-5 text-primary" />
            <h1 className="font-bold">AdelGPT</h1>
          </div>
          <Button onClick={createNewChat} size="sm" variant="outline">
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto">
          {!activeSession ? (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Bot className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Selamat Datang di AdelGPT</h2>
              <p className="text-muted-foreground max-w-md mb-6">
                Asisten AI yang siap membantu Anda. Mulai percakapan baru untuk berbicara dengan AI.
              </p>
              <Button onClick={createNewChat}>
                <Plus className="h-4 w-4 mr-2" /> Mulai Chat Baru
              </Button>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <MessageSquare className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{activeSession.title}</h3>
              <p className="text-muted-foreground">Ketik pesan untuk mulai percakapan</p>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto p-4 space-y-6">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.role === 'assistant' && (
                    <Avatar className="h-8 w-8 shrink-0 mt-1">
                      <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                        <Bot className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                  <div className={`max-w-[80%] ${msg.role === 'user' ? 'order-first' : ''}`}>
                    <Card
                      className={`p-4 ${
                        msg.role === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <div className="prose prose-sm max-w-none break-words [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    </Card>
                  </div>
                  {msg.role === 'user' && (
                    <Avatar className="h-8 w-8 shrink-0 mt-1">
                      <AvatarFallback className="bg-secondary text-xs">
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}
              {isSending && (
                <div className="flex gap-3 justify-start">
                  <Avatar className="h-8 w-8 shrink-0 mt-1">
                    <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                      <Bot className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <Card className="p-4 bg-muted">
                    <div className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span className="text-sm text-muted-foreground">AI sedang berpikir...</span>
                    </div>
                  </Card>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        {activeSession && (
          <div className="border-t p-4">
            <div className="max-w-3xl mx-auto">
              <div className="flex gap-2 items-end">
                <Textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ketik pesan Anda..."
                  className="min-h-[44px] max-h-[200px] resize-none"
                  rows={1}
                  disabled={isSending}
                />
                <Button
                  onClick={sendMessage}
                  disabled={!input.trim() || isSending}
                  size="icon"
                  className="h-[44px] w-[44px] shrink-0"
                >
                  {isSending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Mobile Session Drawer */}
      <div className="md:hidden fixed bottom-20 left-0 right-0 z-10">
        <div className="px-2 overflow-x-auto">
          <div className="flex gap-2 pb-2">
            {sessions.map((session) => (
              <button
                key={session.id}
                onClick={() => selectSession(session)}
                className={`px-3 py-1.5 rounded-full text-xs whitespace-nowrap border transition-colors ${
                  activeSession?.id === session.id
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'bg-background border-border hover:bg-accent'
                }`}
              >
                {session.title.length > 20 ? session.title.substring(0, 20) + '...' : session.title}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
