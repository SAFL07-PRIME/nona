import { create } from 'zustand';

export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  _count?: { messages: number };
}

export type ViewMode = 'chat' | 'admin';

interface AppState {
  // Auth
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;

  // Navigation
  viewMode: ViewMode;
  sidebarOpen: boolean;

  // Chat
  sessions: ChatSession[];
  activeSession: ChatSession | null;
  messages: ChatMessage[];
  isSending: boolean;

  // Auth actions
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  logout: () => void;

  // Navigation actions
  setViewMode: (mode: ViewMode) => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;

  // Chat actions
  setSessions: (sessions: ChatSession[]) => void;
  setActiveSession: (session: ChatSession | null) => void;
  setMessages: (messages: ChatMessage[]) => void;
  addMessage: (message: ChatMessage) => void;
  setSending: (sending: boolean) => void;
}

export const useStore = create<AppState>((set) => ({
  // Auth defaults
  user: null,
  isLoading: true,
  isAuthenticated: false,

  // Navigation defaults
  viewMode: 'chat',
  sidebarOpen: true,

  // Chat defaults
  sessions: [],
  activeSession: null,
  messages: [],
  isSending: false,

  // Auth actions
  setUser: (user) => set({ user, isAuthenticated: !!user, isLoading: false }),
  setLoading: (loading) => set({ isLoading: loading }),
  logout: () => set({
    user: null,
    isAuthenticated: false,
    viewMode: 'chat',
    sessions: [],
    activeSession: null,
    messages: [],
  }),

  // Navigation actions
  setViewMode: (mode) => set({ viewMode: mode }),
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),

  // Chat actions
  setSessions: (sessions) => set({ sessions }),
  setActiveSession: (session) => set({ activeSession: session }),
  setMessages: (messages) => set({ messages }),
  addMessage: (message) => set((state) => ({ messages: [...state.messages, message] })),
  setSending: (sending) => set({ isSending: sending }),
}));
