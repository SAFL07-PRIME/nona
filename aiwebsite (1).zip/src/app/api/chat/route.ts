import { db } from '@/lib/db';
import { requireAuth } from '@/lib/auth';
import { NextRequest, NextResponse } from 'next/server';

// POST /api/chat - Send message to AI
export async function POST(request: NextRequest) {
  try {
    const authUser = await requireAuth();
    const { message, sessionId } = await request.json();

    if (!message || !sessionId) {
      return NextResponse.json(
        { error: 'Message dan sessionId diperlukan' },
        { status: 400 }
      );
    }

    // Validate session belongs to user
    const session = await db.chatSession.findFirst({
      where: { id: sessionId, userId: authUser.userId },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session tidak ditemukan' },
        { status: 404 }
      );
    }

    // Save user message
    await db.chatMessage.create({
      data: {
        userId: authUser.userId,
        sessionId,
        role: 'user',
        content: message,
      },
    });

    // Update session title if it's the first message
    const messageCount = await db.chatMessage.count({
      where: { sessionId },
    });

    if (messageCount <= 1) {
      const title = message.length > 40 ? message.substring(0, 40) + '...' : message;
      await db.chatSession.update({
        where: { id: sessionId },
        data: { title },
      });
    }

    // Get Groq API key from settings
    const groqKeySetting = await db.systemSettings.findUnique({
      where: { key: 'groq_api_key' },
    });

    const groqApiKey = groqKeySetting?.value;
    if (!groqApiKey) {
      const errorMsg = 'API Key Groq belum dikonfigurasi. Silakan hubungi administrator.';
      await db.chatMessage.create({
        data: {
          userId: authUser.userId,
          sessionId,
          role: 'assistant',
          content: errorMsg,
        },
      });
      return NextResponse.json({ reply: errorMsg });
    }

    // Get AI model setting
    const modelSetting = await db.systemSettings.findUnique({
      where: { key: 'ai_model' },
    });
    const aiModel = modelSetting?.value || 'llama-3.3-70b-versatile';

    // Get system prompt setting
    const promptSetting = await db.systemSettings.findUnique({
      where: { key: 'system_prompt' },
    });
    const systemPrompt = promptSetting?.value || 'Kamu adalah asisten AI yang ramah dan membantu. Jawab dengan bahasa yang sama dengan pengguna.';

    // Get recent chat history for context
    const recentMessages = await db.chatMessage.findMany({
      where: { sessionId },
      orderBy: { createdAt: 'asc' },
      take: 20,
    });

    const chatHistory = recentMessages.map(m => ({
      role: m.role,
      content: m.content,
    }));

    // Call Groq API
    const groqResponse = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${groqApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: aiModel,
        messages: [
          { role: 'system', content: systemPrompt },
          ...chatHistory,
        ],
        temperature: 0.7,
        max_tokens: 4096,
      }),
    });

    if (!groqResponse.ok) {
      const errorData = await groqResponse.json().catch(() => ({}));
      const errorMsg = `Groq API Error: ${errorData?.error?.message || groqResponse.statusText}`;
      await db.chatMessage.create({
        data: {
          userId: authUser.userId,
          sessionId,
          role: 'assistant',
          content: errorMsg,
        },
      });
      return NextResponse.json({ reply: errorMsg });
    }

    const data = await groqResponse.json();
    const reply = data.choices?.[0]?.message?.content || 'Maaf, tidak ada respons dari AI.';

    // Save assistant message
    await db.chatMessage.create({
      data: {
        userId: authUser.userId,
        sessionId,
        role: 'assistant',
        content: reply,
      },
    });

    return NextResponse.json({ reply });
  } catch (error: any) {
    if (error.message.includes('Unauthorized')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Chat error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan server' },
      { status: 500 }
    );
  }
}

// GET /api/chat?sessionId=xxx - Get chat messages
export async function GET(request: NextRequest) {
  try {
    const authUser = await requireAuth();
    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('sessionId');

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID diperlukan' },
        { status: 400 }
      );
    }

    const session = await db.chatSession.findFirst({
      where: { id: sessionId, userId: authUser.userId },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session tidak ditemukan' },
        { status: 404 }
      );
    }

    const messages = await db.chatMessage.findMany({
      where: { sessionId },
      orderBy: { createdAt: 'asc' },
      select: { id: true, role: true, content: true, createdAt: true },
    });

    return NextResponse.json({ messages });
  } catch (error: any) {
    if (error.message.includes('Unauthorized')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    return NextResponse.json({ error: 'Terjadi kesalahan' }, { status: 500 });
  }
}

// DELETE /api/chat?sessionId=xxx - Delete chat session
export async function DELETE(request: NextRequest) {
  try {
    const authUser = await requireAuth();
    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('id');

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID diperlukan' },
        { status: 400 }
      );
    }

    const session = await db.chatSession.findFirst({
      where: { id: sessionId, userId: authUser.userId },
    });

    if (!session) {
      return NextResponse.json(
        { error: 'Session tidak ditemukan' },
        { status: 404 }
      );
    }

    await db.chatSession.delete({ where: { id: sessionId } });

    return NextResponse.json({ message: 'Chat berhasil dihapus' });
  } catch (error: any) {
    if (error.message.includes('Unauthorized')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    return NextResponse.json({ error: 'Terjadi kesalahan' }, { status: 500 });
  }
}
