import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { NextRequest, NextResponse } from 'next/server';

export async function GET() {
  try {
    await requireAdmin();

    let groqApiKey = await db.systemSettings.findUnique({
      where: { key: 'groq_api_key' },
    });

    let aiModel = await db.systemSettings.findUnique({
      where: { key: 'ai_model' },
    });

    let systemPrompt = await db.systemSettings.findUnique({
      where: { key: 'system_prompt' },
    });

    return NextResponse.json({
      settings: {
        groqApiKey: groqApiKey?.value || '',
        aiModel: aiModel?.value || 'llama-3.3-70b-versatile',
        systemPrompt: systemPrompt?.value || 'Kamu adalah asisten AI yang ramah dan membantu. Jawab dengan bahasa yang sama dengan pengguna.',
      },
    });
  } catch (error: any) {
    if (error.message.includes('Unauthorized') || error.message.includes('Forbidden')) {
      return NextResponse.json({ error: error.message }, { status: error.message.includes('Forbidden') ? 403 : 401 });
    }
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    await requireAdmin();
    const { groqApiKey, aiModel, systemPrompt } = await request.json();

    const upsertSetting = async (key: string, value: string) => {
      await db.systemSettings.upsert({
        where: { key },
        update: { value },
        create: { key, value },
      });
    };

    if (groqApiKey !== undefined) {
      await upsertSetting('groq_api_key', groqApiKey);
    }
    if (aiModel !== undefined) {
      await upsertSetting('ai_model', aiModel);
    }
    if (systemPrompt !== undefined) {
      await upsertSetting('system_prompt', systemPrompt);
    }

    return NextResponse.json({ message: 'Settings berhasil diperbarui' });
  } catch (error: any) {
    if (error.message.includes('Unauthorized') || error.message.includes('Forbidden')) {
      return NextResponse.json({ error: error.message }, { status: error.message.includes('Forbidden') ? 403 : 401 });
    }
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

// POST /api/admin/settings - Test API key
export async function POST(request: NextRequest) {
  try {
    await requireAdmin();
    const { groqApiKey, aiModel } = await request.json();

    if (!groqApiKey) {
      return NextResponse.json({ error: 'API Key diperlukan' }, { status: 400 });
    }

    const model = aiModel || 'llama-3.3-70b-versatile';

    const groqResponse = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${groqApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: 'test' }],
        max_tokens: 5,
      }),
    });

    if (groqResponse.ok) {
      return NextResponse.json({ success: true, message: 'API Key valid! Groq API terkoneksi.' });
    } else {
      const errorData = await groqResponse.json().catch(() => ({}));
      return NextResponse.json({
        success: false,
        error: errorData?.error?.message || groqResponse.statusText,
      }, { status: groqResponse.status });
    }
  } catch (error: any) {
    if (error.message.includes('Unauthorized') || error.message.includes('Forbidden')) {
      return NextResponse.json({ error: error.message }, { status: error.message.includes('Forbidden') ? 403 : 401 });
    }
    return NextResponse.json({ error: 'Tidak bisa terhubung ke Groq API' }, { status: 500 });
  }
}
