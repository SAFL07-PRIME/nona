import { db } from '@/lib/db';
import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';

// Seed admin user - run this once to create the admin account
export async function POST() {
  try {
    // Check if admin already exists
    const existingAdmin = await db.user.findUnique({ where: { email: 'admin@adelgpt.com' } });
    if (existingAdmin) {
      return NextResponse.json({
        message: 'Admin sudah ada',
        admin: { email: 'admin@adelgpt.com', name: existingAdmin.name },
      });
    }

    const hashedPassword = await bcrypt.hash('admin123', 12);

    const admin = await db.user.create({
      data: {
        email: 'admin@adelgpt.com',
        password: hashedPassword,
        name: 'Administrator',
        role: 'ADMIN',
      },
      select: { id: true, email: true, name: true, role: true },
    });

    // Set default system settings
    await db.systemSettings.upsert({
      where: { key: 'groq_api_key' },
      update: {},
      create: { key: 'groq_api_key', value: '' },
    });

    await db.systemSettings.upsert({
      where: { key: 'ai_model' },
      update: {},
      create: { key: 'ai_model', value: 'llama-3.3-70b-versatile' },
    });

    await db.systemSettings.upsert({
      where: { key: 'system_prompt' },
      update: {},
      create: {
        key: 'system_prompt',
        value: 'Kamu adalah AdelGPT, asisten AI yang ramah dan membantu. Jawab dengan bahasa yang sama dengan pengguna.',
      },
    });

    return NextResponse.json({
      message: 'Admin berhasil dibuat',
      admin,
      credentials: {
        email: 'admin@adelgpt.com',
        password: 'admin123',
      },
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || 'Terjadi kesalahan' },
      { status: 500 }
    );
  }
}
