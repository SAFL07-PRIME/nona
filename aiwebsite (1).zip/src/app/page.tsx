'use client';

import { useEffect, useCallback } from 'react';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';
import AuthModal from '@/components/AuthModal';
import ChatInterface from '@/components/ChatInterface';
import AdminPanel from '@/components/AdminPanel';
import { Loader2, LogOut, Bot, Settings } from 'lucide-react';

export default function Home() {
  const {
    user, isLoading, isAuthenticated, viewMode,
    setUser, setLoading, logout, setViewMode,
  } = useStore();

  const checkAuth = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/me');
      if (res.ok) {
        const data = await res.json();
        if (data.user) {
          setUser(data.user);
        } else {
          setUser(null);
        }
      } else {
        setUser(null);
      }
    } catch {
      setUser(null);
    }
  }, [setUser]);

  useEffect(() => {
    checkAuth();
    fetch('/api/seed', { method: 'POST' }).catch(() => {});
  }, [checkAuth]);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/me', { method: 'DELETE' });
      logout();
      toast.success('Logout berhasil');
    } catch {
      toast.error('Gagal logout');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Memuat AdelGPT...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <>
        <AuthModal />
        <Toaster richColors position="top-center" />
      </>
    );
  }

  return (
    <>
      {viewMode === 'chat' ? <ChatInterface /> : <AdminPanel />}

      <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2">
        {user.role === 'ADMIN' && (
          <Button
            variant={viewMode === 'admin' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode(viewMode === 'admin' ? 'chat' : 'admin')}
            className="shadow-lg"
          >
            {viewMode === 'admin' ? (
              <><Bot className="h-4 w-4 mr-2" /> Chat</>
            ) : (
              <><Settings className="h-4 w-4 mr-2" /> Admin</>
            )}
          </Button>
        )}
        <Button variant="outline" size="sm" onClick={handleLogout} className="shadow-lg">
          <LogOut className="h-4 w-4 mr-2" /> Logout
        </Button>
      </div>

      <Toaster richColors position="top-center" />
    </>
  );
}
